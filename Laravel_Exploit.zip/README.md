# Laravel_Exploit
Laravel PHPUNIT Rce Auto Exploit &amp; Retrieving information in .env (such as SMTP, AWS, TWILIO,  SSH, NEXMO, PERFECTMONEY, and other.)

# how to run?
      git clone https://github.com/404rgr/Laravel_Exploit
      cd Laravel_Exploit
      # use python2
      python laravel.py
